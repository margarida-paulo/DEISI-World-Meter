package pt.aed.ulusofona.deisiworldmeter;

import javax.xml.crypto.Data;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.*;

public class Main {
    public static ArrayList<Pais> dataPaises = new ArrayList<>();
    public static ArrayList<Cidade> dataCidades = new ArrayList<>();
    public static ArrayList<Populacao> dataPopulacao = new ArrayList<>();
    public static ArrayList<TipoInvalido> dataInvalidos = new ArrayList<>();

    /// enumerdado que o prof quer ///
    enum TipoIdentidade {
        PAIS, CIDADE, TIPO_INVALIDO
    }

    /**
     *
     * @param ficheiro Ficheiro .csv a ser lido
     * @param tipoData 0 -> Ficheiro de Países ; 1 -> Ficheiro de cidades ; 2 -> Ficheiro de População
     * @return False se a leitura do ficheiro falhar ou este estiver desformatado, true se estiver tudo correto.
     */
    static Boolean parseEachFile(String ficheiro, int tipoData){
        File ficheiroLido = new File(ficheiro);
        boolean primeiraLinha = true;
        int linhaCount = 0;
        Scanner scanner;

        try {
            scanner = new Scanner(ficheiroLido);
        } catch (FileNotFoundException e) {
            return false;
        }

        while (scanner.hasNext()){
            if (primeiraLinha){
                scanner.nextLine();
                primeiraLinha = false;
            }
            else {
                String linha = scanner.nextLine();
                String[] linhaDividida = linha.split(",");
                switch (tipoData){
                    case 0 -> {
                        if (linhaDividida.length != 4){
                            return false;
                        }
                        try {
                            Integer.parseInt(linhaDividida[0]);
                        } catch (NumberFormatException e) {
                            linhaDividida[0] = "-1";
                        }
                        dataPaises.add(new Pais(Integer.parseInt(linhaDividida[0]), linhaDividida[1], linhaDividida[2], linhaDividida[3], linhaCount));
                    }
                    case 1 -> {
                        if (linhaDividida.length != 6){
                            return false;
                        }

                        try {
                            Integer.parseInt(linhaDividida[2]);
                        } catch (NumberFormatException e) {
                            linhaDividida[2] = "-1";
                        }

                        try {
                            Float.parseFloat(linhaDividida[3]);
                        } catch (NumberFormatException f) {
                            linhaDividida[3] = "-1.0";
                        }

                        try {
                            Float.parseFloat(linhaDividida[4]);
                        } catch (NumberFormatException g) {
                            linhaDividida[4] = "-1.0";
                        }

                        try {
                            Float.parseFloat(linhaDividida[5]);
                        } catch (NumberFormatException h) {
                            linhaDividida[5] = "-1.0";
                        }
                        dataCidades.add(new Cidade(linhaDividida[0],linhaDividida[1], Integer.parseInt(linhaDividida[2]), Float.parseFloat(linhaDividida[3]), Float.parseFloat(linhaDividida[4]), Float.parseFloat(linhaDividida[5]), linhaCount));
                    }
                    case 2 -> {
                        if (linhaDividida.length != 5){
                            return false;
                        }

                        try {
                            Integer.parseInt(linhaDividida[0]);
                        } catch (NumberFormatException e) {
                            linhaDividida[0] = "-1";
                        }

                        try {
                            Integer.parseInt(linhaDividida[1]);
                        } catch (NumberFormatException f) {
                            linhaDividida[1] = "-1";
                        }

                        try {
                            Integer.parseInt(linhaDividida[2]);
                        } catch (NumberFormatException g) {
                            linhaDividida[2] = "-1";
                        }

                        try {
                            Integer.parseInt(linhaDividida[3]);
                        } catch (NumberFormatException h) {
                            linhaDividida[3] = "-1";
                        }

                        try {
                            Float.parseFloat(linhaDividida[4]);
                        } catch (NumberFormatException h) {
                            linhaDividida[4] = "-1.0";
                        }
                        dataPopulacao.add(new Populacao(Integer.parseInt(linhaDividida[0]), Integer.parseInt(linhaDividida[1]), Integer.parseInt(linhaDividida[2]), Integer.parseInt(linhaDividida[3]), Float.parseFloat(linhaDividida[4]), linhaCount));
                    }
                }

            }
            linhaCount++;
        }
        return true;
    }
    /**
     *
     * @param pasta Pasta que contém os ficheiros .csv
     * @return True, caso tenha conseguido ler todos os ficheiros corretamente, ou false, caso não tenha.
     */
    static Boolean parseFiles(File pasta) {
        if (!parseEachFile(pasta + "/paises.csv", 0)) {
            return false;
        }
        if (!parseEachFile(pasta + "/cidades.csv", 1)){
            return false;
        }
        if (!parseEachFile(pasta + "/populacao.csv", 2)){
           return false;
       }
        return true;
    }

    static ArrayList getObject(TipoIdentidade tipo) {
        ArrayList informacaoCarregada;
        ArrayList novaInformacao = new ArrayList();

        informacaoCarregada = switch (tipo) {
            case PAIS -> dataPaises;
            case CIDADE -> dataCidades;
            case TIPO_INVALIDO -> dataInvalidos;
        };
        if (informacaoCarregada != null) {
            novaInformacao.addAll(informacaoCarregada); // Adiciona todas as informações carregadas para a nova lista
        }
        return novaInformacao;
    }

    public static void main(String[] args) {
        System.out.println("Bem vindo ao DEISI World Meter");
        System.out.println();
        if (parseFiles(new File("Data"))) {
            int i = 0;
            ArrayList country = getObject(TipoIdentidade.PAIS);
            while (i < country.size()) {
                System.out.println(country.get(i).toString());
                i++;
            }
        }
    }
}
