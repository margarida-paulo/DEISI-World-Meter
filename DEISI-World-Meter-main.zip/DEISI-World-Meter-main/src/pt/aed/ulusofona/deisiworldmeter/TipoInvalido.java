package pt.aed.ulusofona.deisiworldmeter;
public class TipoInvalido {
    String nomeDoFicheiro;
    int numeroLinhasOk;
    int numeroLinhasNaoOk;
    int primieraLinhaNaoOK;
    public TipoInvalido(String nomeDoFicheiro, int numeroLinhasOk, int numeroLinhasNaoOk, int primieraLinhaNaoOK) {
        this.nomeDoFicheiro = nomeDoFicheiro;
        this.numeroLinhasOk = numeroLinhasOk;
        this.numeroLinhasNaoOk = numeroLinhasNaoOk;
        this.primieraLinhaNaoOK = primieraLinhaNaoOK;
    }
    public String toString() {
        return nomeDoFicheiro + " | " + numeroLinhasOk + " | " + numeroLinhasNaoOk + " | " + primieraLinhaNaoOK;
    }
}
